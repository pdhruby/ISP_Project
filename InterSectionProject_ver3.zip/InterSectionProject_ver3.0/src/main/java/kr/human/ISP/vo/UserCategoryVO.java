package kr.human.ISP.vo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@AllArgsConstructor
@NoArgsConstructor
@Data
public class UserCategoryVO {
	public int user_category_idx;
	public int user_idx;
	public int category_idx;
}
